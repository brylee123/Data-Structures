#include "StockTracker.h"

StockTracker::StockTracker(){}


void StockTracker::registerTicker(string tickerSymbol, int sharesOutstanding){
    // TODO
}

bool StockTracker::isTicker(string tickerSymbol){
    // TODO
}

int StockTracker::getSharesOutstanding(string tickerSymbol){
    // TODO
}


void StockTracker::updateCurrentPrice(string tickerSymbol, double price){
    // TODO
}

double StockTracker::getCurrentPrice(string tickerSymbol){
    // TODO
}

double StockTracker::getMarketCap(string tickerSymbol){
    // TODO
}


vector<string> StockTracker::topMarketCaps(int k){
    // TODO
}